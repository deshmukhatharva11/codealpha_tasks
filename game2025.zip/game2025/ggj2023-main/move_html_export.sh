#!/bin/bash
mkdir -p server/staticfiles/g/
cp -r exports/* server/staticfiles/g/
