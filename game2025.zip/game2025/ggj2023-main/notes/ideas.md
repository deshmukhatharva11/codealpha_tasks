### Roots

## 1. Root puzzle game 2D

You can grow root in multiple places in a 2d jump/run game. 
You need to grow them in the right locations to solve the level.

## 2. Roots Arcade .io

Like agario but you grow root and can grow through the roots from others ( making them shorter ).
Every now and then you can grow roots into the ground so if someone cuts of your root you only loos the part untill a point which has grown into the ground.


## 3. Worms roots

A turn based game where you can either shoot or grow roots. Roots can be destroyed by weapons.


## 4. Roots 2 player battle

The player are 'roots' you can never walk but at the beginninng of every turn you can 'grow'.
You may only grow untill you hit a wall the there you are stationary. 

After you 'grow' you can fight. You have a flame trower and can burn root or hit the other player.
The player that kills the other player first winns.
