### Dev-repo

Private now, make public at end of jam
https://github.com/tbscode/ggj2023.git

### TODO's / Task list

https://docs.google.com/spreadsheets/d/1FG71SiLLMBqbbAsTYl80vUC5DhDVec6CNi5LjcG5X2Y/edit?usp=sharing

### Drive

https://drive.google.com/drive/folders/1ocX6PuLAvCSEKhAYePWz4n25dZnVyKAR?usp=sharing

### Docs

# creating shader masks

https://godotengine.org/qa/36050/2d-texture-mask-shader-to-simply-mask-part-of-sprite-in-godot

# Convert high res images to simple pixel art:

https://giventofly.github.io/pixelit/

# Simple online game mecanic

Every player that opens the app gets a random user-hash.
You may personalize your account and add an own username and password.

When logged in there a two options:

1. enter lobby by loby name
2. enter random loby ( request a game lobby queue )

# Doing the authentication with godot:

https://godotengine.org/qa/70514/http-request-using-basic-auth
